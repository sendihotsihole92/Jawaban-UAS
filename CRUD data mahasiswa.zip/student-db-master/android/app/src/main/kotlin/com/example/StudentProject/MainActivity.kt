package com.example.StudentProject

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
