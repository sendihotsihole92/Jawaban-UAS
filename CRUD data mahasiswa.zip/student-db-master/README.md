# [Archived]Student-db
### See [this](https://github.com/sonuishaq67/SMS) for details
#### Front end of the Student Database is made using Flutter which supports full CRUD operations

This is basically a student academic information registration application which allows the student to track their data easily. (**It ensures data probity**)

This Project allows Students to see their details by entering their credentials

## Preview

![](assets/giphy.gif)

### To download on android download the [apk](https://github.com/42ip/student-db/releases/download/v1.0.0/app-release.apk)

### To download on linux distributions [AppImage](https://github.com/42ip/student-db/releases/download/1.0.0/StudentProject-1.0.0-x86_64.AppImage)
``` chmod +x StudentProject-1.0.0-x86_64.AppImage```

```./StudentProject-1.0.0-x86_64.AppImage```
