## Tentang saya
Halo, Saya **A.M Hirin** seorang ***Penulis Buku IT***, ***International Freelance Programmer***, dan ***Senior Developer*** di Perusahaan Konsultan IT. Saya penggila kode dan sudah berkutat selama 15 tahun di dunia pemrograman. Anda membutuhkan bantuan terkait skill dan keahlian saya? Kontak saya melalui email : **nump.info@gmail.com**

# eduprog_flutter_crud

Contoh CRUD pada Flutter (PHP +MySQL)

## Preview

Preview 1:

![Image of a preview 1][pre1]

Preview 2:

![Image of a preview 2][pre2]

[pre1]: ./source_backend/1.png
[pre2]: ./source_backend/2.png


## Salam

A.M Hirin

www.eduprog.net

